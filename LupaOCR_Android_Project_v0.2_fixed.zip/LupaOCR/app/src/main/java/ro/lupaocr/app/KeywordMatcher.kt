package ro.lupaocr.app

import java.text.Normalizer
import java.util.Locale

enum class MatchMode {
    EXACT,
    STARTS_WITH,
    CONTAINS
}

data class MatchConfig(
    val mode: MatchMode = MatchMode.STARTS_WITH,
    val characterLimit: Int? = null,
    val ignoreDiacritics: Boolean = true
)

object KeywordMatcher {
    private val combiningMarks = Regex("\\p{M}+")
    private val outerPunctuation = Regex("^[\\p{P}\\p{S}]+|[\\p{P}\\p{S}]+$")
    private val whitespace = Regex("\\s+")

    fun parseTerms(raw: String): List<String> = raw
        .lineSequence()
        .map { it.trim() }
        .filter { it.isNotEmpty() }
        .distinctBy { normalize(it, ignoreDiacritics = true) }
        .toList()

    fun normalize(value: String, ignoreDiacritics: Boolean): String {
        var text = value.lowercase(Locale.ROOT).trim()
        text = text.replace(whitespace, " ")
        if (ignoreDiacritics) {
            text = Normalizer.normalize(text, Normalizer.Form.NFD)
                .replace(combiningMarks, "")
        }
        return text
    }

    fun normalizeToken(value: String, ignoreDiacritics: Boolean): String =
        normalize(value, ignoreDiacritics).replace(outerPunctuation, "")

    fun effectiveQuery(term: String, config: MatchConfig): String {
        val normalized = normalizeToken(term, config.ignoreDiacritics)
        if (config.mode == MatchMode.EXACT) return normalized
        val limit = config.characterLimit
        return if (limit != null && limit > 0 && normalized.length > limit) {
            normalized.take(limit)
        } else {
            normalized
        }
    }

    fun matches(candidate: String, term: String, config: MatchConfig): Boolean {
        val c = normalizeToken(candidate, config.ignoreDiacritics)
        val q = effectiveQuery(term, config)
        if (c.isBlank() || q.isBlank()) return false
        return when (config.mode) {
            MatchMode.EXACT -> c == q
            MatchMode.STARTS_WITH -> c.startsWith(q)
            MatchMode.CONTAINS -> c.contains(q)
        }
    }

    /**
     * A phrase is considered an exact phrase when the exact normalized word sequence
     * occurs anywhere in the OCR line. This is intentionally literal, not semantic.
     */
    fun phraseOccurs(line: String, phrase: String, config: MatchConfig): Boolean {
        val normalizedLine = normalize(line, config.ignoreDiacritics)
        val normalizedPhrase = normalize(phrase, config.ignoreDiacritics)
        if (normalizedLine.isBlank() || normalizedPhrase.isBlank()) return false

        return if (config.mode == MatchMode.EXACT) {
            val escaped = Regex.escape(normalizedPhrase)
            Regex("(^|\\s)$escaped($|\\s)").containsMatchIn(normalizedLine)
        } else {
            val q = if (config.characterLimit != null && config.characterLimit > 0) {
                normalizedPhrase.take(config.characterLimit)
            } else normalizedPhrase
            when (config.mode) {
                MatchMode.STARTS_WITH -> normalizedLine.split(' ').any { it.startsWith(q) } || normalizedLine.contains(q)
                MatchMode.CONTAINS -> normalizedLine.contains(q)
                MatchMode.EXACT -> false
            }
        }
    }
}
