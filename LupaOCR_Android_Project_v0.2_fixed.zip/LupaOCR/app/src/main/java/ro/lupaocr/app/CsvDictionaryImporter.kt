package ro.lupaocr.app

import java.io.BufferedReader
import java.io.InputStream
import java.io.InputStreamReader
import java.nio.charset.StandardCharsets

object CsvDictionaryImporter {
    data class ImportResult(val imported: Int, val skipped: Int)

    fun import(
        inputStream: InputStream,
        sourceName: String,
        database: DictionaryDatabase
    ): ImportResult {
        BufferedReader(InputStreamReader(inputStream, StandardCharsets.UTF_8)).use { reader ->
            val firstLine = generateSequence { reader.readLine() }
                .firstOrNull { it.isNotBlank() }
                ?: return ImportResult(0, 0)

            val delimiter = detectDelimiter(firstLine)
            val header = parseLine(firstLine.removePrefix("\uFEFF"), delimiter)
                .map { canonical(it) }

            val termIndex = findIndex(header, setOf("term", "termen", "cuvant", "word"))
            val definitionIndex = findIndex(header, setOf("definition", "definitie", "sens", "meaning"))
            val synonymsIndex = findIndex(header, setOf("synonyms", "sinonime", "sinonim"))
            val antonymsIndex = findIndex(header, setOf("antonyms", "antonime", "antonim"))
            val sourceIndex = findIndex(header, setOf("source", "sursa"))

            require(termIndex >= 0 && definitionIndex >= 0) {
                "CSV-ul trebuie să aibă coloane pentru termen și definiție (ex.: term,definition)."
            }

            var imported = 0
            var skipped = 0
            val db = database.writableDatabase
            db.beginTransaction()
            try {
                reader.forEachLine { line ->
                    if (line.isBlank()) return@forEachLine
                    val row = parseLine(line, delimiter)
                    val term = row.getOrNull(termIndex)?.trim().orEmpty()
                    val definition = row.getOrNull(definitionIndex)?.trim().orEmpty()
                    if (term.isBlank() || definition.isBlank()) {
                        skipped++
                        return@forEachLine
                    }

                    val rowSource = if (sourceIndex >= 0) row.getOrNull(sourceIndex).orEmpty().trim() else ""
                    database.insertOrReplace(
                        DictionaryEntry(
                            term = term,
                            definition = definition,
                            synonyms = if (synonymsIndex >= 0) row.getOrNull(synonymsIndex).orEmpty() else "",
                            antonyms = if (antonymsIndex >= 0) row.getOrNull(antonymsIndex).orEmpty() else "",
                            source = rowSource.ifBlank { sourceName }
                        ),
                        db
                    )
                    imported++
                }
                db.setTransactionSuccessful()
            } finally {
                db.endTransaction()
            }
            return ImportResult(imported, skipped)
        }
    }

    private fun canonical(value: String): String = KeywordMatcher
        .normalizeToken(value, ignoreDiacritics = true)
        .replace(" ", "")

    private fun findIndex(header: List<String>, names: Set<String>): Int =
        header.indexOfFirst { it in names }

    private fun detectDelimiter(line: String): Char {
        val candidates = listOf(',', ';', '\t')
        return candidates.maxByOrNull { delimiter -> countOutsideQuotes(line, delimiter) } ?: ','
    }

    private fun countOutsideQuotes(line: String, delimiter: Char): Int {
        var quoted = false
        var count = 0
        var i = 0
        while (i < line.length) {
            when (val c = line[i]) {
                '"' -> {
                    if (quoted && i + 1 < line.length && line[i + 1] == '"') i++
                    else quoted = !quoted
                }
                delimiter -> if (!quoted) count++
            }
            i++
        }
        return count
    }

    private fun parseLine(line: String, delimiter: Char): List<String> {
        val result = ArrayList<String>()
        val current = StringBuilder()
        var quoted = false
        var i = 0
        while (i < line.length) {
            val c = line[i]
            when {
                c == '"' && quoted && i + 1 < line.length && line[i + 1] == '"' -> {
                    current.append('"')
                    i++
                }
                c == '"' -> quoted = !quoted
                c == delimiter && !quoted -> {
                    result += current.toString()
                    current.clear()
                }
                else -> current.append(c)
            }
            i++
        }
        result += current.toString()
        return result
    }
}
