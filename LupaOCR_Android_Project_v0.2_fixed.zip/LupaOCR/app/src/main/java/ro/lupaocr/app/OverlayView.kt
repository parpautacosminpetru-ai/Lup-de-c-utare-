package ro.lupaocr.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.os.SystemClock
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import kotlin.math.PI
import kotlin.math.sin


data class VisualMatch(
    val rect: RectF,
    val ocrText: String,
    val searchTerm: String
)

class OverlayView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = resources.displayMetrics.density * 2.5f
    }

    private var matches: List<VisualMatch> = emptyList()
    var pulseEnabled: Boolean = true
    var onMatchTapped: ((VisualMatch) -> Unit)? = null

    fun setMatches(newMatches: List<VisualMatch>) {
        matches = newMatches.map { it.copy(rect = RectF(it.rect)) }
        invalidate()
    }

    fun clearMatches() {
        matches = emptyList()
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (matches.isEmpty()) return

        val now = SystemClock.uptimeMillis()
        val wave = if (pulseEnabled) {
            ((sin((now % 900L) / 900.0 * 2.0 * PI) + 1.0) / 2.0).toFloat()
        } else 1f
        val fillAlpha = (75 + 95 * wave).toInt().coerceIn(0, 255)
        val strokeAlpha = (175 + 80 * wave).toInt().coerceIn(0, 255)

        fillPaint.style = Paint.Style.FILL
        fillPaint.color = Color.argb(fillAlpha, 255, 235, 59)
        strokePaint.color = Color.argb(strokeAlpha, 255, 87, 34)

        val radius = resources.displayMetrics.density * 5f
        for (match in matches) {
            canvas.drawRoundRect(match.rect, radius, radius, fillPaint)
            canvas.drawRoundRect(match.rect, radius, radius, strokePaint)
        }

        if (pulseEnabled) postInvalidateOnAnimation()
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.action != MotionEvent.ACTION_UP) return true
        val x = event.x
        val y = event.y
        val hit = matches
            .filter { it.rect.contains(x, y) }
            .minByOrNull { it.rect.width() * it.rect.height() }
        if (hit != null) {
            onMatchTapped?.invoke(hit)
            performClick()
            return true
        }
        return false
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }
}
