package ro.lupaocr.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.database.Cursor
import android.graphics.Color
import android.graphics.RectF
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.text.Editable
import android.text.TextWatcher
import android.util.Size
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.mlkit.vision.MlKitAnalyzer
import androidx.camera.view.CameraController
import androidx.camera.view.LifecycleCameraController
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class MainActivity : ComponentActivity() {

    companion object {
        private const val CAMERA_PERMISSION_REQUEST = 1001
        private const val DICTIONARY_FILE_REQUEST = 1002
    }

    private lateinit var previewView: PreviewView
    private lateinit var overlayView: OverlayView
    private lateinit var statusText: TextView
    private lateinit var termsInput: EditText
    private lateinit var modeSpinner: Spinner
    private lateinit var limitCheck: CheckBox
    private lateinit var limitSeek: SeekBar
    private lateinit var limitLabel: TextView
    private lateinit var diacriticsCheck: CheckBox
    private lateinit var pulseCheck: CheckBox
    private lateinit var torchButton: Button
    private lateinit var cameraButton: Button
    private lateinit var dictionaryWord: TextView
    private lateinit var dictionaryBody: TextView
    private lateinit var dictionaryCount: TextView

    private lateinit var cameraController: LifecycleCameraController
    private lateinit var textRecognizer: TextRecognizer
    private lateinit var dictionaryDatabase: DictionaryDatabase

    private val analysisExecutor: ExecutorService = Executors.newSingleThreadExecutor()
    private val ioExecutor: ExecutorService = Executors.newSingleThreadExecutor()

    @Volatile private var searchTerms: List<String> = emptyList()
    @Volatile private var matchConfig = MatchConfig()
    private var cameraActive = false
    private var torchOn = false
    @Volatile private var lastDictionaryLookupNorm: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        dictionaryDatabase = DictionaryDatabase(this)
        textRecognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

        buildUi()
        setupCameraController()
        updateDictionaryCount()

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            startCamera()
        } else {
            requestPermissions(arrayOf(Manifest.permission.CAMERA), CAMERA_PERMISSION_REQUEST)
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(245, 245, 245))
        }

        val cameraFrame = FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
        }
        root.addView(cameraFrame, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            0,
            1.25f
        ))

        previewView = PreviewView(this).apply {
            scaleType = PreviewView.ScaleType.FILL_CENTER
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
        }
        cameraFrame.addView(previewView, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        ))

        overlayView = OverlayView(this).apply {
            isClickable = true
            onMatchTapped = { match -> showDictionaryFor(match.ocrText, force = true) }
        }
        cameraFrame.addView(overlayView, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        ))

        statusText = TextView(this).apply {
            text = "Introdu termenii de căutare."
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.argb(170, 0, 0, 0))
            setPadding(dp(10), dp(7), dp(10), dp(7))
            textSize = 14f
        }
        cameraFrame.addView(statusText, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT,
            Gravity.TOP
        ))

        val scroll = ScrollView(this).apply {
            isFillViewport = false
        }
        root.addView(scroll, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            0,
            0.75f
        ))

        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(8), dp(10), dp(12))
        }
        scroll.addView(panel, ScrollView.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ))

        panel.addView(TextView(this).apply {
            text = "Cuvinte / expresii — un termen pe fiecare linie"
            textSize = 14f
            setTextColor(Color.DKGRAY)
        })

        termsInput = EditText(this).apply {
            hint = "univers\ncercetare\nmetodologie\nuniversitate publică"
            gravity = Gravity.TOP or Gravity.START
            minLines = 3
            maxLines = 6
            setHorizontallyScrolling(false)
            setPadding(dp(8), dp(6), dp(8), dp(6))
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                    searchTerms = KeywordMatcher.parseTerms(s?.toString().orEmpty())
                    updateStatusForNoFrame()
                }
                override fun afterTextChanged(s: Editable?) = Unit
            })
        }
        panel.addView(termsInput, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            dp(100)
        ))

        val modeRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        panel.addView(modeRow, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ))

        modeRow.addView(TextView(this).apply {
            text = "Potrivire: "
            textSize = 14f
        })

        modeSpinner = Spinner(this)
        val modes = listOf("Exact", "Începe cu", "Conține")
        modeSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, modes)
        modeSpinner.setSelection(1)
        modeSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                if (::limitCheck.isInitialized) limitCheck.isEnabled = position != 0
                if (::limitSeek.isInitialized && ::limitCheck.isInitialized) {
                    limitSeek.isEnabled = position != 0 && limitCheck.isChecked
                }
                rebuildConfig()
            }
            override fun onNothingSelected(parent: AdapterView<*>?) = Unit
        }
        modeRow.addView(modeSpinner, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

        val cameraControls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        panel.addView(cameraControls)

        cameraButton = Button(this).apply {
            text = "Oprește camera"
            setOnClickListener {
                if (cameraActive) stopCamera() else ensureCameraAndStart()
            }
        }
        cameraControls.addView(cameraButton, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

        torchButton = Button(this).apply {
            text = "Lanternă OFF"
            setOnClickListener { toggleTorch() }
        }
        cameraControls.addView(torchButton, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

        limitCheck = CheckBox(this).apply {
            text = "Folosește doar primele N caractere (pentru Începe cu / Conține)"
            isChecked = false
            setOnCheckedChangeListener { _, _ ->
                if (::limitSeek.isInitialized) {
                    limitSeek.isEnabled = isChecked && modeSpinner.selectedItemPosition != 0
                }
                rebuildConfig()
            }
        }
        panel.addView(limitCheck)

        val limitRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        panel.addView(limitRow)

        limitSeek = SeekBar(this).apply {
            max = 49
            progress = 5 // 6 caractere
            isEnabled = false
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    limitLabel.text = "N = ${progress + 1}"
                    rebuildConfig()
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
                override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
            })
        }
        limitRow.addView(limitSeek, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        limitLabel = TextView(this).apply {
            text = "N = 6"
            setPadding(dp(8), 0, 0, 0)
        }
        limitRow.addView(limitLabel)

        val behaviorRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }
        panel.addView(behaviorRow)

        diacriticsCheck = CheckBox(this).apply {
            text = "Ignoră diferența de diacritice"
            isChecked = true
            setOnCheckedChangeListener { _, _ -> rebuildConfig() }
        }
        behaviorRow.addView(diacriticsCheck, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

        pulseCheck = CheckBox(this).apply {
            text = "Clipire vizuală"
            isChecked = true
            setOnCheckedChangeListener { _, checked -> overlayView.pulseEnabled = checked }
        }
        behaviorRow.addView(pulseCheck, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

        val dictRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        panel.addView(dictRow)

        val importButton = Button(this).apply {
            text = "Importă dicționar CSV"
            setOnClickListener { openDictionaryFile() }
        }
        dictRow.addView(importButton, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

        dictionaryCount = TextView(this).apply {
            text = "0 termeni"
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), 0, 0, 0)
        }
        dictRow.addView(dictionaryCount, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

        val dictionaryBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(8), dp(10), dp(8))
            setBackgroundColor(Color.rgb(232, 238, 245))
        }
        panel.addView(dictionaryBox, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(6) })

        dictionaryWord = TextView(this).apply {
            text = "Dicționar offline"
            textSize = 22f
            setTextColor(Color.rgb(20, 20, 20))
        }
        dictionaryBox.addView(dictionaryWord)

        dictionaryBody = TextView(this).apply {
            text = "Când este găsit un termen, definiția locală apare aici. Poți atinge orice highlight pentru a-l verifica."
            textSize = 14f
            setTextColor(Color.DKGRAY)
            maxLines = 8
        }
        dictionaryBox.addView(dictionaryBody)

        setContentView(root)
        rebuildConfig()
    }

    private fun setupCameraController() {
        cameraController = LifecycleCameraController(this).apply {
            cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA
            setEnabledUseCases(CameraController.IMAGE_ANALYSIS)
            setImageAnalysisBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
            setImageAnalysisResolutionSelector(
                ResolutionSelector.Builder()
                    .setResolutionStrategy(
                        ResolutionStrategy(
                            Size(1280, 720),
                            ResolutionStrategy.FALLBACK_RULE_CLOSEST_HIGHER_THEN_LOWER
                        )
                    )
                    .build()
            )
            setImageAnalysisAnalyzer(
                analysisExecutor,
                MlKitAnalyzer(
                    listOf(textRecognizer),
                    ImageAnalysis.COORDINATE_SYSTEM_VIEW_REFERENCED,
                    analysisExecutor
                ) { result ->
                    val text = result.getValue(textRecognizer)
                    if (text != null) processOcrResult(text)
                }
            )
        }
        previewView.controller = cameraController
    }

    private fun ensureCameraAndStart() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            startCamera()
        } else {
            requestPermissions(arrayOf(Manifest.permission.CAMERA), CAMERA_PERMISSION_REQUEST)
        }
    }

    private fun startCamera() {
        try {
            cameraController.bindToLifecycle(this)
            cameraActive = true
            cameraButton.text = "Oprește camera"
        } catch (e: Exception) {
            cameraActive = false
            cameraButton.text = "Pornește camera"
            Toast.makeText(this, "Camera nu a putut porni: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun stopCamera() {
        torchOn = false
        try { cameraController.enableTorch(false) } catch (_: Exception) { }
        cameraController.unbind()
        cameraActive = false
        cameraButton.text = "Pornește camera"
        torchButton.text = "Lanternă OFF"
        overlayView.clearMatches()
        statusText.text = "Camera este oprită."
    }

    private fun toggleTorch() {
        if (!cameraActive) return
        torchOn = !torchOn
        try {
            cameraController.enableTorch(torchOn)
            torchButton.text = if (torchOn) "Lanternă ON" else "Lanternă OFF"
        } catch (e: Exception) {
            torchOn = false
            torchButton.text = "Lanternă indisponibilă"
        }
    }

    private fun processOcrResult(text: Text) {
        val terms = searchTerms
        if (terms.isEmpty()) {
            runOnUiThread {
                overlayView.clearMatches()
                statusText.text = "Introdu termenii de căutare."
            }
            return
        }

        val config = matchConfig
        val visualByArea = LinkedHashMap<String, VisualMatch>()
        val matchedTerms = LinkedHashSet<String>()

        for (block in text.textBlocks) {
            for (line in block.lines) {
                val elements = line.elements
                if (elements.isEmpty()) continue

                for (term in terms) {
                    val phraseParts = term.trim().split(Regex("\\s+")).filter { it.isNotBlank() }
                    if (phraseParts.size <= 1) {
                        for (element in elements) {
                            if (!KeywordMatcher.matches(element.text, term, config)) continue
                            val box = element.boundingBox ?: continue
                            val rect = RectF(box)
                            val key = areaKey(rect)
                            visualByArea.putIfAbsent(
                                key,
                                VisualMatch(rect, element.text, term)
                            )
                            matchedTerms += term
                        }
                    } else {
                        val ranges = findPhraseRanges(elements, phraseParts, config)
                        for (range in ranges) {
                            var union: RectF? = null
                            val words = ArrayList<String>()
                            for (index in range) {
                                val element = elements[index]
                                words += element.text
                                val box = element.boundingBox ?: continue
                                if (union == null) union = RectF(box) else union.union(RectF(box))
                            }
                            val rect = union ?: continue
                            val key = areaKey(rect)
                            visualByArea.putIfAbsent(
                                key,
                                VisualMatch(rect, words.joinToString(" "), term)
                            )
                            matchedTerms += term
                        }
                    }
                }
            }
        }

        val matches = visualByArea.values.toList()
        runOnUiThread {
            overlayView.setMatches(matches)
            statusText.text = if (matches.isEmpty()) {
                "Nimic din listă pe cadrul curent • ${terms.size} termeni activi"
            } else {
                "Găsite: ${matches.size} zone • ${matchedTerms.size}/${terms.size} termeni"
            }
        }

        matches.firstOrNull()?.let { showDictionaryFor(it.ocrText, force = false) }
    }

    private fun findPhraseRanges(
        elements: List<Text.Element>,
        phraseParts: List<String>,
        config: MatchConfig
    ): List<IntRange> {
        if (phraseParts.size > elements.size) return emptyList()
        val ranges = ArrayList<IntRange>()
        for (start in 0..elements.size - phraseParts.size) {
            var all = true
            for (offset in phraseParts.indices) {
                if (!KeywordMatcher.matches(elements[start + offset].text, phraseParts[offset], config)) {
                    all = false
                    break
                }
            }
            if (all) ranges += start..(start + phraseParts.size - 1)
        }
        return ranges
    }

    private fun areaKey(rect: RectF): String =
        "${rect.left.toInt()}:${rect.top.toInt()}:${rect.right.toInt()}:${rect.bottom.toInt()}"

    private fun rebuildConfig() {
        if (!::modeSpinner.isInitialized || !::diacriticsCheck.isInitialized || !::limitCheck.isInitialized) return
        val mode = when (modeSpinner.selectedItemPosition) {
            0 -> MatchMode.EXACT
            2 -> MatchMode.CONTAINS
            else -> MatchMode.STARTS_WITH
        }
        val limit = if (mode != MatchMode.EXACT && limitCheck.isChecked) limitSeek.progress + 1 else null
        matchConfig = MatchConfig(
            mode = mode,
            characterLimit = limit,
            ignoreDiacritics = diacriticsCheck.isChecked
        )
    }

    private fun updateStatusForNoFrame() {
        if (!::statusText.isInitialized) return
        val size = searchTerms.size
        if (size == 0) statusText.text = "Introdu termenii de căutare."
        else statusText.text = "$size termeni activi • caut simultan"
    }

    private fun showDictionaryFor(word: String, force: Boolean) {
        val normalized = KeywordMatcher.normalizeToken(word, ignoreDiacritics = true)
        if (normalized.isBlank()) return
        if (!force && normalized == lastDictionaryLookupNorm) return
        lastDictionaryLookupNorm = normalized

        ioExecutor.execute {
            val entries = dictionaryDatabase.lookup(word)
            runOnUiThread {
                dictionaryWord.text = word
                dictionaryBody.text = if (entries.isEmpty()) {
                    "Nu există o intrare exactă pentru acest termen în dicționarele locale importate."
                } else {
                    entries.joinToString("\n\n") { entry ->
                        buildString {
                            if (entry.source.isNotBlank()) append("[${entry.source}]\n")
                            append(entry.definition)
                            if (entry.synonyms.isNotBlank()) append("\nSinonime: ${entry.synonyms}")
                            if (entry.antonyms.isNotBlank()) append("\nAntonime: ${entry.antonyms}")
                        }
                    }
                }
            }
        }
    }

    private fun openDictionaryFile() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
        }
        startActivityForResult(intent, DICTIONARY_FILE_REQUEST)
    }

    @Deprecated("Deprecated in Android framework, kept here to minimize dependencies in this small app.")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != DICTIONARY_FILE_REQUEST || resultCode != Activity.RESULT_OK) return
        val uri = data?.data ?: return
        importDictionary(uri)
    }

    private fun importDictionary(uri: Uri) {
        dictionaryWord.text = "Import dicționar…"
        dictionaryBody.text = "Se citește fișierul local."
        val sourceName = queryDisplayName(uri).ifBlank { "Dicționar local" }

        ioExecutor.execute {
            try {
                val result = contentResolver.openInputStream(uri)?.use { input ->
                    CsvDictionaryImporter.import(input, sourceName, dictionaryDatabase)
                } ?: error("Fișierul nu poate fi deschis.")

                runOnUiThread {
                    lastDictionaryLookupNorm = ""
                    dictionaryWord.text = "Dicționar importat"
                    dictionaryBody.text = "${result.imported} intrări importate; ${result.skipped} rânduri ignorate."
                    updateDictionaryCount()
                }
            } catch (e: Exception) {
                runOnUiThread {
                    dictionaryWord.text = "Import nereușit"
                    dictionaryBody.text = e.message ?: "Format necunoscut."
                }
            }
        }
    }

    private fun queryDisplayName(uri: Uri): String {
        var cursor: Cursor? = null
        return try {
            cursor = contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            if (cursor != null && cursor.moveToFirst()) cursor.getString(0).orEmpty() else ""
        } catch (_: Exception) {
            ""
        } finally {
            cursor?.close()
        }
    }

    private fun updateDictionaryCount() {
        ioExecutor.execute {
            val count = dictionaryDatabase.countEntries()
            runOnUiThread {
                if (::dictionaryCount.isInitialized) dictionaryCount.text = "$count intrări"
            }
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == CAMERA_PERMISSION_REQUEST) {
            if (grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) startCamera()
            else statusText.text = "Permisiunea camerei este necesară pentru lupa OCR."
        }
    }

    override fun onDestroy() {
        try { cameraController.clearImageAnalysisAnalyzer() } catch (_: Exception) { }
        textRecognizer.close()
        dictionaryDatabase.close()
        analysisExecutor.shutdown()
        ioExecutor.shutdown()
        super.onDestroy()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
